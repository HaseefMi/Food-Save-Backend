from rest_framework import serializers
from .models import Product, Restaurant, CustomUser, Order

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['name', 'original_price', 'discounted_price', 'image_url', 'restaurant', 'category', 'order_by', 'status', 'date_created', 'description', 'restaurant_logo', 'address', 'inventory', 'id']

class RestaurantSerializer(serializers.ModelSerializer):
    class Meta:
        model = Restaurant
        fields = ['name', 'logo', 'closing_time', 'address']


from rest_framework import serializers
from .models import CustomUser

class CustomUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['username', 'password', 'stripe_id']
    
class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = ['full_name', 'email', 'phone', 'restaurant', 'order', 'date_created', 'id']
    
