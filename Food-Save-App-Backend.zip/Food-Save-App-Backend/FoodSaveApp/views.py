from django.db.models import Q
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .models import Product, Restaurant, CustomUser, Order
from .serializers import ProductSerializer, RestaurantSerializer, OrderSerializer
from rest_framework import status
from django.utils import timezone
from django.core.paginator import Paginator
import pytz
from rest_framework import status
import stripe
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.shortcuts import get_object_or_404


@api_view(['GET', 'POST', 'PATCH', 'DELETE'])
def product_list(request, pk=None):
    if request.method == 'GET':
        category_name = request.query_params.get('category', None)
        restaurant_name = request.query_params.get('restaurant', None)

        eastern = pytz.timezone('America/New_York')
        current_date = timezone.now().astimezone(eastern).date()
        current_time = timezone.now().astimezone(eastern).time()

        filters = Q(date_created=current_date) & Q(order_by__time__gte=current_time) & Q(inventory__gt=0)

        if category_name:
            filters &= Q(category__iexact=category_name)
        if restaurant_name:
            filters &= Q(restaurant__iexact=restaurant_name)

        products = Product.objects.filter(filters)

        paginator = Paginator(products, 25)
        page_number = request.query_params.get('page')
        page_obj = paginator.get_page(page_number)

        serializer = ProductSerializer(page_obj, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    if request.method == 'POST':
        serialized_product = ProductSerializer(data = request.data)
        serialized_product.is_valid(raise_exception=True)
        serialized_product.save()
        return Response(serialized_product._validated_data, status=status.HTTP_201_CREATED)
    if request.method == 'DELETE':
        if pk is None:
            return JsonResponse({'Error': 'No Product ID given'}, status=status.HTTP_400_BAD_REQUEST)
        product = get_object_or_404(Product, id=pk)
        product.delete()
        return JsonResponse({'Success': 'Product Deleted'}, status=status.HTTP_200_OK)
    if request.method == 'PATCH':
        pk = request.data.get('pk')
    value_to_change = request.data.get('value_to_change')
    updated_value = request.data.get('updated_value')
    
    if not pk or not value_to_change or not updated_value:
        return Response({"error": "Missing parameters"}, status=status.HTTP_400_BAD_REQUEST)

    try:
        product = Product.objects.get(pk=pk)
    except Product.DoesNotExist:
        return Response({"error": "Product not found"}, status=status.HTTP_404_NOT_FOUND)
    
    if not hasattr(product, value_to_change):
        return Response({"error": "Invalid field name"}, status=status.HTTP_400_BAD_REQUEST)
    
    if value_to_change == 'price':
        try:
            updated_value = float(updated_value)
        except ValueError:
            return Response({"error": "Invalid value for price"}, status=status.HTTP_400_BAD_REQUEST)
    
    setattr(product, value_to_change, updated_value)
    product.save()
    serializer = ProductSerializer(product)
    return Response(serializer.data, status=status.HTTP_200_OK)
        

        

@api_view(['GET'])
def restaurant_list(request):
    if request.method == 'GET':
        restaurants = Restaurant.objects.all()
        serialized_restaurant_items = RestaurantSerializer(restaurants, many=True)
        return Response(serialized_restaurant_items.data, status=status.HTTP_200_OK)

stripe.api_key = settings.STRIPE_SECRET_KEY


@api_view(['POST'])
def login(request):
    try:
        email = request.data.get('email')
        if not email:
            return JsonResponse({'Error': 'No Email Provided'}, status=status.HTTP_400_BAD_REQUEST)
        try:
            restaurant_info = Restaurant.objects.get(email__iexact=email)
        except Restaurant.DoesNotExist:
            return JsonResponse({"Error": 'No Restaurant Found with provided email'}, status=status.HTTP_404_NOT_FOUND)
        serialized_restaurant = RestaurantSerializer(restaurant_info)
        return Response(serialized_restaurant.data, status=status.HTTP_200_OK)
    except Exception as e:
        return JsonResponse({'Error': 'Error Retrieving Business Info', 'Details': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    

@api_view(['POST'])
@csrf_exempt
def create_payment_intent(request):
    try:
        data = request.data
        amount = int(float(data.get('amount')))  
        restaurant_name = data.get('restaurant')  
        payment_method = data.get('payment_method')
        fee = int(float(data.get('fee')))  
        return_url = 'https://www.cnn.com/'

        if not restaurant_name or not amount or not payment_method or not fee: 
            return JsonResponse({'error': 'Missing required fields'}, status=status.HTTP_400_BAD_REQUEST)

        user = CustomUser.objects.get(username__iexact=restaurant_name)

        if not user.stripe_id:
            return JsonResponse({'error': 'Connected account ID not found for user'}, status=status.HTTP_404_NOT_FOUND)

        connected_account_id = user.stripe_id

        payment_intent = stripe.PaymentIntent.create(
            amount=amount,
            currency='cad',
            payment_method=payment_method,
            confirm=True,
            transfer_data={
                'destination': connected_account_id
            },
            application_fee_amount=fee,
            return_url=return_url
        )

        return Response({
            'client_secret': payment_intent.client_secret
        })
    except stripe.error.CardError as e:
        return JsonResponse({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
    except stripe.error.StripeError as e:
        return JsonResponse({'error': 'An error occurred with Stripe: ' + str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    except CustomUser.DoesNotExist:
        return JsonResponse({'error': 'Restaurant not found'}, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return JsonResponse({'error': 'An unexpected error occurred: ' + str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['GET', 'POST'])
def order_list(request):
    if request.method == 'GET':
        restaurant = request.GET.get('restaurant')
        if not restaurant:
            return JsonResponse({'Error': 'No Restaurant is Provided'}, status=status.HTTP_400_BAD_REQUEST)
        eastern = pytz.timezone('America/New_York')
        current_date = timezone.now().astimezone(eastern).date()
        filters = Q(date_created=current_date)
        filters &= Q(restaurant__iexact=restaurant)
        products = Order.objects.filter(filters)
        paginator = Paginator(products, 25)
        page_number = request.GET.get('page', 1)
        page_obj = paginator.get_page(page_number)
        serializer = OrderSerializer(page_obj, many=True)
        serialized_data = serializer.data
        return JsonResponse({'orders': serialized_data}, status=status.HTTP_200_OK)
    if request.method == 'POST':
        try: 
            products = request.data.get('products')
            for item, quantity in products.items():
                product = Product.objects.get(name__iexact = item)
                product.inventory = product.inventory - quantity
                product.save()
        except:
            return JsonResponse({'Error' : 'Product Quantity(s) failed to update'}, status=status.HTTP_400_BAD_REQUEST)
        serializer = OrderSerializer(data = request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer._validated_data, status=status.HTTP_201_CREATED)