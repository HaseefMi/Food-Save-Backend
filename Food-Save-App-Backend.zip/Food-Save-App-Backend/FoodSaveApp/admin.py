from django.contrib import admin
from .models import Product, Restaurant, CustomUser, Order

admin.site.register(Product)
admin.site.register(Restaurant)
admin.site.register(CustomUser)
admin.site.register(Order)
