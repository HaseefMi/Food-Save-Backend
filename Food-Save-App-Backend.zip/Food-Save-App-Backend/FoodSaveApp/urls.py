from django.urls import path
from . import views


urlpatterns = [
    path('product-list/', views.product_list, name='product-list'),
    path('restaurant-list/', views.restaurant_list, name='restaurant-list'),
    path('login', views.login, name='login'),
    path('create-payment', views.create_payment_intent, name='create-payment'),
    path('product-list/<int:pk>/', views.product_list, name='product_detail'),
    path('order-list/', views.order_list, name='order-list'),
]