from django.db import models
import datetime

class Product(models.Model):
    name = models.CharField(max_length=255)
    original_price = models.DecimalField(max_digits=5, decimal_places=2)
    discounted_price = models.DecimalField(max_digits=5, decimal_places=2)
    image_url = models.URLField(max_length=200)
    restaurant_logo = models.URLField(max_length=200)
    restaurant = models.CharField(max_length=255, db_index=True)
    description = models.TextField()
    category = models.CharField(max_length=255, db_index=True, null=True, blank=True)
    order_by = models.DateTimeField(db_index=True)
    status = models.CharField(max_length=255)
    date_created = models.DateField(default=datetime.date.today, db_index=True)
    address = models.CharField(max_length=300)
    inventory = models.IntegerField(default=0)

    class Meta:
        indexes = [
            models.Index(fields=['category', 'date_created', 'order_by']),
            models.Index(fields=['restaurant', 'date_created', 'order_by']),
        ]

class Restaurant(models.Model):
    name = models.CharField(max_length=255)
    logo = models.URLField(max_length=200)
    closing_time = models.CharField(max_length=255)
    email = models.CharField(max_length=255, default="")
    address = models.CharField(max_length=255, default="")

class CustomUser(models.Model):
    username = models.CharField(max_length=150, unique=True)
    password = models.CharField(max_length=128)
    stripe_id = models.CharField(max_length=255, blank=True, null=True)

class Order(models.Model):
    full_name = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    phone = models.CharField(max_length=255)
    order = models.CharField(max_length=300)
    restaurant = models.CharField(max_length=255, db_index=True)
    date_created = models.DateField(default=datetime.date.today, db_index=True)

    class Meta:
        indexes = [
            models.Index(fields=['restaurant', 'date_created'])
        ]